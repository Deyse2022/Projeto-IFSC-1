package com.everis.listadecontatos.feature.listacontatos.model

data class ContatosVO(
    var id: Int = -1,
    var nome: String = "",
    var telefone: String = ""
)