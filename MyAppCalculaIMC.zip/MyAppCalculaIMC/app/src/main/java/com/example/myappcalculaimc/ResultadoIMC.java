package com.example.myappcalculaimc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class ResultadoIMC extends AppCompatActivity {

    TextView resultado;
    String strNome;
    Float fltAltura, fltPeso, fltResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resultado_imc);

        resultado = (TextView) findViewById(R.id.textViewResultado);

        Intent intent = getIntent();
        strNome = intent.getStringExtra("nome");
        fltAltura = Float.parseFloat(intent.getStringExtra("altura"));
        fltPeso = Float.parseFloat(intent.getStringExtra("peso"));
        fltResultado = fltPeso / (fltAltura * fltAltura);

        String strResult = "Olá " + strNome + "!";
        strResult = strResult + "\n" + "IMC = " + fltResultado.toString();
        //resultado.setText("IMC = " + fltResultado.toString());

        if (fltResultado < 17) {

            strResult = strResult + "\n" + "Você está muito abaixo do peso";

        }else if(fltResultado < 18.49){
                strResult = strResult + "\n" + "Você está abaixo do peso";
            }
            else if(fltResultado < 24.99){
                strResult = strResult + "\n" + "Seu peso está normal";
            }
            else if(fltResultado < 29.99){
                strResult = strResult + "\n" + "Você está acima do peso";
            }
            else if(fltResultado < 34.99){
                strResult = strResult + "\n" + "Obesidade I";
            }
            else if(fltResultado < 39.99){
                strResult = strResult + "\n" + "Obesidade II (severa)";
            }
            else {
                strResult = strResult + "\n" + "Obesidade III (mórbida)";
            }
        resultado.setText(strResult);
    }
}