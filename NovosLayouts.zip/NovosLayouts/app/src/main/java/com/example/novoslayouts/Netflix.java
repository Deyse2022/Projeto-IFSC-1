package com.example.novoslayouts;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Netflix extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_netflix);
    }
}