package com.example.blocodenotas;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.blocodenotas.controller.NotaController;
import com.example.blocodenotas.modelo.Nota;

public class CadastrarActivity extends AppCompatActivity {


    NotaController mNoteController;
    Nota mNote;
    EditText edTitulo, edTxt;
    Button bntCadastrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exibir);

        edTitulo = findViewById(R.id.edTitulo);
        edTxt = findViewById(R.id.edtxt);
        mNoteController = new NotaController(getApplicationContext());
        mNote = new Nota(edTitulo.getText().toString(),edTxt.getText().toString());
        bntCadastrar = findViewById(R.id.bntSalvar);
        bntCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cadastraNota();
            }
        });

    }

    private void cadastraNota() {
        mNote.setTitulo(edTitulo.getText().toString());
        mNote.setTxt(edTxt.getText().toString());
        mNoteController.cadastrarNota(mNote);
        finish();
    }
}
