package com.example.blocodenotas.controller;


import android.content.Context;

import com.example.blocodenotas.modelo.Nota;
import com.example.blocodenotas.modelo.NotaDao;

import java.util.ArrayList;

public class NotaController {
    NotaDao mNotaDao;

    public NotaController(Context context) {
        mNotaDao=new NotaDao(context);

    }

    public void cadastrarNota(Nota nota){
        mNotaDao.insertNota(nota);


    }
    public void updateNota(Nota mNota){
        mNotaDao.upadateNota(mNota);
    }
    public void delteNota(Nota mNota){
        mNotaDao.deleteNota(mNota);

    }
    public ArrayList<Nota> getAllNote(){
        return mNotaDao.getAllNotes();

    }
    public ArrayList<String> getAllTitlesNotes(){
        ArrayList<String> stringArrayListTitulos= new ArrayList<String>();
        for (Nota n: getAllNote()) {
            stringArrayListTitulos.add(n.getTitulo());
        }
        return  stringArrayListTitulos;
    }


    public Nota getNota(int id){

        return mNotaDao.getNota(id);
    }

}