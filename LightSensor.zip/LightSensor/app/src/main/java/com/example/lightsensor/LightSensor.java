package com.example.lightsensor;

import androidx.appcompat.app.AppCompatActivity;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.TextView;

//SensorEventListener – Interface que especifica os métodos que os objetos de
//uma classe que vão receber os eventos dos sensores deve implementar para
//que o Framework consiga notificar as mudanças nos sensores. Os métodos da
//interface são: onSensorChanged e onAccuracyChanged.
public class LightSensor extends AppCompatActivity implements SensorEventListener {

    //SensorManager – Classe que possibilita listar os sensores, obter instancia
    //deles( acessá-los) e registrar a intenção de ouvir os eventos dos sensores (uma
    //mudança no valor dos sensores).
    SensorManager mSensorManager;

    //Sensor – Classe abstrai um sensor especifico e pode conter diversas
    //propriedades, utilizamos objetos desta classe para acessar um sensor especifico
    Sensor mSensorLight;
    TextView mTvLight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_light_sensor );
        mTvLight=findViewById( R.id.tvSensorList );

        mSensorManager = (SensorManager) getSystemService( getApplicationContext().SENSOR_SERVICE );
        mSensorLight = mSensorManager.getDefaultSensor( Sensor.TYPE_LIGHT );
        mSensorManager.registerListener( this, mSensorLight, SensorManager.SENSOR_DELAY_NORMAL);
    }

    //SensorEvent – Classe que abstrai os eventos que ocorrem com os sensores,
    //toda mudança que ocorre no estado de um sensor é instanciado um objeto
    //deste que contém as informações do evento. Este objeto contém o dado raw do
    //sensor, acurraria e timestamp
    @Override
    public void onSensorChanged(SensorEvent event) {
        int sensorType = event.sensor.getType();

        float currentValue = event.values[0];
        mTvLight.setText( Float.toString( currentValue ) );
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
}