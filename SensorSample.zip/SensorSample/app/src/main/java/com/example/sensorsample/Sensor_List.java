package com.example.sensorsample;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class Sensor_List extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensor_list2);
    }
}